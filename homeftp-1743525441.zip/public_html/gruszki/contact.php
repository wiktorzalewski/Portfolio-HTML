<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Pobieramy i oczyszczamy dane z formularza
    $name = htmlspecialchars(trim($_POST["name"]));
    $email = htmlspecialchars(trim($_POST["email"]));
    $message = htmlspecialchars(trim($_POST["message"]));

    // Prosta walidacja – wszystkie pola muszą być wypełnione
    if (empty($name) || empty($email) || empty($message)) {
        echo "Wszystkie pola formularza są wymagane.";
        exit;
    }

    // Adres e-mail właściciela strony: ustawiony na wikzaldod@gmail.com
    $ownerEmail = "wikzaldod@gmail.com";
    $subjectToOwner = "Nowa wiadomość z formularza kontaktowego";
    $bodyToOwner = "Otrzymano nową wiadomość:\n\nImię: $name\nEmail: $email\nWiadomość:\n$message";
    $headersOwner = "From: $email\r\nReply-To: $email";

    // Wysyłamy e-mail do właściciela strony
    $mailToOwner = mail($ownerEmail, $subjectToOwner, $bodyToOwner, $headersOwner);

    // Przygotowanie automatycznej odpowiedzi dla użytkownika
    $subjectToUser = "Dziękujemy za kontakt";
    $bodyToUser = "Dzień dobry $name,\n\nDziękujemy za przesłanie wiadomości. Otrzymaliśmy Twoje zapytanie i udzielimy odpowiedzi możliwie jak najszybciej.\n\nPozdrawiamy,\nZespół";
    // Używamy tego samego adresu jako nadawcy odpowiedzi (upewnij się, że domena nadawcy jest skonfigurowana na serwerze)
    $headersUser = "From: wikzaldod@gmail.com\r\nReply-To: wikzaldod@gmail.com";

    // Wysyłamy automatyczną odpowiedź
    $mailToUser = mail($email, $subjectToUser, $bodyToUser, $headersUser);

    if ($mailToOwner) {
        echo "Wiadomość wysłana pomyślnie. Dziękujemy za kontakt.";
    } else {
        echo "Wystąpił błąd podczas wysyłania wiadomości. Spróbuj ponownie.";
    }
} else {
    // Jeśli ktoś próbuje wejść bezpośrednio do tego pliku, przekierowujemy go do formularza kontaktowego.
    header("Location: kontakt.html");
    exit;
}
?>
